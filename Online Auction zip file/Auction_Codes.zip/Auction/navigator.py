word = "hello"
