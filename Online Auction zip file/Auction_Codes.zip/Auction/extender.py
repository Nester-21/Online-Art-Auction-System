
from urllib import request
from bottle	 import *

import os


import navigator

def getStartUpDir():
	_path = str(navigator)[0:-2]
	_ph = _path.split("/")
	_path = _path.replace(_ph[0] , "")
	_path = _path.replace(_ph[-1] , "")
	return _path

TruePath = getStartUpDir()
os.chdir(TruePath)

app = Bottle()

def readFile(fl):
	fd = open(fl , "r+")
	dat = fd.read()
	fd.close()
	
	return dat

def Rfile(fl):
	fd = open(fl , "r+")
	data = fd.read()
	fd.close()
	
	return data

def readBin(fl):
	fd = open(fl , "rb+")
	dat = fd.read()
	fd.close()
	
	return dat

def writeBin(fname , data):
	x = open(fname ,"wb+")
	x.write(data)
	x.close()



def router():
	return readFile("master.html")
	

def router2():
	return readFile("home.html")

def icons(ics):
	return readBin("./icons/" + ics)

def arts(ats):
	return readBin("./Art_pieces/" + ats + ".jpeg")

def artprofs(ats):
	prof = ""
	try:
		prof =  readBin("./Artists/" + ats + ".jpg")
	except Exception as e:
		prof =  readBin("./Artists/profile.png")
	return prof



def src(_src):
	return readFile("./scripts/" + _src)


@app.route("/narts" , method=["POST"])
def handle_narts():

	dat =  readFile("./databases/artists.js")
	
	dat = eval(dat)

	dat2 =  readFile("./databases/artworks.js")
	dat2 = eval(dat2)

	

	result = {'status': 'success', 'artists': dat , 'arts':dat2}
	response.headers['Content-Type'] = 'application/json'
	return result

app.route("/pnl")(router)
app.route("/home")(router2)
app.route("/ico/<ics:path>")(icons)
app.route("/artpcs/<ats:path>")(arts)
app.route("/artistsProfs/<ats:path>")(artprofs)
app.route("/_src_/<_src:path>")(src)


app.run(host="" , port = "9080")
