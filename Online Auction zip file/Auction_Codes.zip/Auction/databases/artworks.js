{
    "ArtWorks":
    [
        ["ArtName" ,"ImageID", "Type{painting , digital NFT,,}" , "Dimensions" ,"Price", "Price Changes" ,"Production Year" , "Artist ID" ],
        ["OutReach"  ,"181920_1903" , "Painting" , "1mx1mx0.05m" , "25K" , "3" , "2017" , "181920"],
        ["Bliss"  , "181920_6705", "Painting" , "0.3mx0.6mx0.08m" , "15K" , "2" , "2017" , "181920"],
        ["Concealed"  ,"113589_1489" , "Painting" , "1mx1mx0.065m" , "131K" , "5" , "2011" , "113589"],
        ["Simplified"  ,"603412_8074" , "Painting" , "0.8mx1mx0.05m" , "25K" , "4" , "2019" , "603412"],
        ["Fading"  ,"901678_1243" , "Sculpture" , "0.5mx0.5mx0.5m" , "55K" , "2" , "2024" , "901678"]
    ]
}